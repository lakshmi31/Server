package server;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.ServerSocket;
import java.net.Socket;
/** @author ldudhbha */
public final class DestinationServer {
    /**
     * Default Constructor.
     */
    private DestinationServer() {
    }
    private static Socket socket;

    public static void main(String[] args) {
        try {

            int port = 8081;
            @SuppressWarnings("resource")
            ServerSocket serverSocket = new ServerSocket(port);
            System.out.println("Server Started and listening to the port 8081");

            //Server is running always. This is done using this while(true) loop
            while (true) {
                //Reading the message from the client
                socket = serverSocket.accept();
                InputStream is = socket.getInputStream();
                InputStreamReader isr = new InputStreamReader(is);
                BufferedReader br = new BufferedReader(isr);
                String message = br.readLine();
                System.out.println("Message received from client is " + message);

                CustomerResponseDest customerResponseDest = new CustomerResponseDest();
                String returnMessage = null;
                if (message != null && !message.isEmpty()) {
                    customerResponseDest.setSuccessMessage("Success\r\n");
                    returnMessage = customerResponseDest.getSuccessMessage();
                } else {
                    customerResponseDest.setErrorCode("Error\r\n");
                    returnMessage = customerResponseDest.getErrorCode();
                }

                //Sending the response back to the client.
                OutputStream os = socket.getOutputStream();
                OutputStreamWriter osw = new OutputStreamWriter(os);
                BufferedWriter bw = new BufferedWriter(osw);
                bw.write(returnMessage);
                System.out.println("Message sent to the client is:\n" + returnMessage);
                bw.flush();
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                socket.close();
            } catch (Exception e) {
            }
        }
    }
}
