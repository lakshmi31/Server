package server;

import java.io.Serializable;
/**
 * Destination Response Class.
 */
public class CustomerResponseDest implements Serializable {
    /** Serialization default ID. */
    private static final long serialVersionUID = 1L;

    /** Response Error code. */
    private String errorCode;
    /** Response Success Message. */
    private String successMessage;
    /** Source Identifier. */
    private String sourceIdentifier;
    /** Correlation ID. */
    private String correlationID;

    /** @return the errorCode. */
    public String getErrorCode() {
        return errorCode;
    }
    /** @param errorCode the errorCode to set. */
    public void setErrorCode(String errorCode) {
        this.errorCode = errorCode;
    }
    /** @return the successMessage. */
    public String getSuccessMessage() {
        return successMessage;
    }
    /** @param successMessage the successMessage to set. */
    public void setSuccessMessage(String successMessage) {
        this.successMessage = successMessage;
    }
    /** @return the sourceIdentifier. */
    public String getSourceIdentifier() {
        return sourceIdentifier;
    }
    /** @param sourceIdentifier the sourceIdentifier to set. */
    public void setSourceIdentifier(String sourceIdentifier) {
        this.sourceIdentifier = sourceIdentifier;
    }
    /** @return the correlationID. */
    public String getCorrelationID() {
        return correlationID;
    }
    /** @param correlationID the correlationID to set. */
    public void setCorrelationID(String correlationID) {
        this.correlationID = correlationID;
    }
    /** @param errorCode response error code.
     * @param successMessage response success message
     * @param sourceIdentifier source identification ID
     * @param correlationID correlation ID */
    public CustomerResponseDest(String errorCode, String successMessage, String sourceIdentifier,
            String correlationID) {
        super();
        this.errorCode = errorCode;
        this.successMessage = successMessage;
        this.sourceIdentifier = sourceIdentifier;
        this.correlationID = correlationID;
    }
    /** Default Constructor. */
    public CustomerResponseDest() {

    }
    /*
     * (non-Javadoc)
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        return errorCode + " " + successMessage + " " + sourceIdentifier + " " + correlationID;
    }

}